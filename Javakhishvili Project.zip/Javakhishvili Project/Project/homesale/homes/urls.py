from django.urls import path
from. import views
from django.contrib.auth.views import LogoutView
from django.conf import settings
from django.conf.urls.static import static
from . views import home_image_view


urlpatterns = [
  path('', views.list_homes, name='list_homes'),
  path('add/', views.add_Home, name='add_home'),
  path('<int:home_id>/', views.home_detail, name='home_detail'),
  path('<int:home_id>/edit/', views.update_home, name='update_home'),
  path('<int:home_id>/delete/', views.delete_home, name='delete_home'),
  path('login/', views.CustomLoginView.as_view(), name='login'),
  path('logout/', LogoutView.as_view(next_page = 'login'), name='logout'),
  path('register/', views.RegisterPage.as_view(), name='register'),
  # path('upload/', views.image_upload_view, name='image_upload'),
  path('image_upload', home_image_view, name='image_upload'),
]
