from django.shortcuts import render, redirect
from django.http import HttpRequest, HttpResponse
from django.views.generic.list import ListView
from django.shortcuts import render, get_object_or_404
from django.views.generic.edit import CreateView, UpdateView, DeleteView, FormView
from django.urls import reverse_lazy
from . models import Home
from django.views.generic.edit import  FormView
# Login / Logout
from django.contrib.auth.views import LoginView
# Registration
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import login
from .forms import HomeForm
from django.core.paginator import Paginator




# Mixins
# from django.contrib.auth.mixins import LoginRequiredMixin
class RegisterPage(FormView):
  template_name = 'homes/register.html'
  form_class = UserCreationForm
  success_url = reverse_lazy('list_homes')
  redirect_authenticated_user = True
  
  def form_valid(self, form):
    user = form.save()

    if user is not None:
      login(self.request, user)

      return super(RegisterPage, self).form_valid(form)
    
    def get(self, *args, **kwargs):
     if self.request.user.is_authenticated:
      return redirect('list_homes')
     return super(RegisterPage, self).get(*args, **kwargs)

class CustomLoginView(LoginView):
  template_name = 'homes/login.html'
  fields = '__all__'
  redirect_authenticated_user = True


  def get_success_url(self):
    return reverse_lazy('list_homes')
  
  def get(self, *args, **kwargs):
    if self.request.user.is_authenticated:
     return redirect('list_homes')
    
    return super(CustomLoginView, self).get(*args, **kwargs)



def list_homes(request):
  Homes = Home.objects.all()

  pagiator = Paginator(Homes, 6)
  page_number = request.GET.get('page')
  page_obj = pagiator.get_page(page_number)

  contex = {
    'homes': page_obj
  }

  return render(request, "homes/all_homes.html", contex,)





def add_Home(request):
  if request.method == "POST":
    city = request.POST.get('city')
    address = request.POST.get('address')
    publication_date = request.POST.get('publication_date')
    number = request.POST.get('number')
    
    

    new_home = Home(
      city=city,
      address=address,
      publication_date=publication_date,
      number=number,
      
   
   

    )

    new_home.save()

    return render(request, "homes/add_home.html", {'text': 'home add succesfuly'}) 
  
  return render(request, "homes/add_home.html") 

#upload images
def home_image_view(request):
    if request.method == 'POST':
        form = HomeForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()

            return redirect('success')
        else:
           form = HomeForm()
        return render(request, 'home_image_form.html', {'form': form})


def success(request):
    return HttpResponse('successfully uploaded')
        




def home_detail(request, home_id):
  home_info = get_object_or_404(Home, pk=home_id)

  return render(request, "homes/home_detail.html", {'home_info': home_info})


def update_home(request, home_id):
  home_info = get_object_or_404(Home, pk=home_id)

  if request.method == 'GET':
    return render(request, "homes/update_home.html", {'home_info': home_info})
  else:
    home_info.city = request.POST.get('city')
    home_info.address = request.POST['address']
    home_info.publication_date = request.POST['publication_date']
    home_info.number = request.POST['number']

    home_info.save()

    return render(request, "homes/update_home.html",
                  {'home_info': home_info,
                   'text': 'home Updated Successfully'})


def delete_home(request, home_id):
  home_for_delete = get_object_or_404(Home, pk=home_id)

  home_for_delete.delete()

  return render(request, "homes/delete_home.html",
    {'home_for_delete': f"Home '{home_for_delete}' deleted successfully"})


