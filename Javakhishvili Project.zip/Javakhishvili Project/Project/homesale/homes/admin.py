from django.contrib import admin

from .models import Home

admin.site.register(Home)
